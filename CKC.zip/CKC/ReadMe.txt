1. This application uses Hardcodet.NotifyIcon.Wpf package provided by Philipp Sumi, which is under The Code Project Open License (CPOL) 1.02.


Hardcodet.NotifyIcon.Wpf package 
	- Version 1.1.0
	- Authors: Philipp Sumi, Robin Krom, Jan Karger





2. git ignore file is taken from: https://github.com/github/gitignore/blob/master/VisualStudio.gitignore